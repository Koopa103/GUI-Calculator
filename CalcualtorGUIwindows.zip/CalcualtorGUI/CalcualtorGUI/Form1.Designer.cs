﻿namespace CalcualtorGUI
{
    partial class Calculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_9 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.Output = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(69, 186);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "AC";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_1
            // 
            this.button_1.Location = new System.Drawing.Point(69, 224);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(45, 24);
            this.button_1.TabIndex = 1;
            this.button_1.Text = "1";
            this.button_1.UseVisualStyleBackColor = true;
            this.button_1.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_4
            // 
            this.button_4.Location = new System.Drawing.Point(69, 264);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(45, 24);
            this.button_4.TabIndex = 1;
            this.button_4.Text = "4";
            this.button_4.UseVisualStyleBackColor = true;
            this.button_4.Click += new System.EventHandler(this.button_4_Click);
            // 
            // button_7
            // 
            this.button_7.Location = new System.Drawing.Point(69, 303);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(45, 24);
            this.button_7.TabIndex = 1;
            this.button_7.Text = "7";
            this.button_7.UseVisualStyleBackColor = true;
            this.button_7.Click += new System.EventHandler(this.button_7_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(69, 344);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(113, 24);
            this.button5.TabIndex = 1;
            this.button5.Text = "0";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button_8
            // 
            this.button_8.Location = new System.Drawing.Point(137, 303);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(45, 24);
            this.button_8.TabIndex = 1;
            this.button_8.Text = "8";
            this.button_8.UseVisualStyleBackColor = true;
            this.button_8.Click += new System.EventHandler(this.button_8_Click);
            // 
            // button_5
            // 
            this.button_5.Location = new System.Drawing.Point(137, 264);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(45, 24);
            this.button_5.TabIndex = 1;
            this.button_5.Text = "5";
            this.button_5.UseVisualStyleBackColor = true;
            this.button_5.Click += new System.EventHandler(this.button8_Click);
            // 
            // button_9
            // 
            this.button_9.Location = new System.Drawing.Point(206, 303);
            this.button_9.Name = "button_9";
            this.button_9.Size = new System.Drawing.Size(45, 24);
            this.button_9.TabIndex = 1;
            this.button_9.Text = "9";
            this.button_9.UseVisualStyleBackColor = true;
            this.button_9.Click += new System.EventHandler(this.button_9_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(206, 344);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(45, 24);
            this.button13.TabIndex = 1;
            this.button13.Text = ".";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button6_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(283, 303);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(45, 24);
            this.button14.TabIndex = 1;
            this.button14.Text = "X";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(283, 186);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(45, 23);
            this.button19.TabIndex = 0;
            this.button19.Text = "/";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button17_Click);
            // 
            // button_2
            // 
            this.button_2.Location = new System.Drawing.Point(137, 224);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(45, 24);
            this.button_2.TabIndex = 3;
            this.button_2.Text = "2";
            this.button_2.UseVisualStyleBackColor = true;
            this.button_2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button_3
            // 
            this.button_3.Location = new System.Drawing.Point(206, 224);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(45, 24);
            this.button_3.TabIndex = 4;
            this.button_3.Text = "3";
            this.button_3.UseVisualStyleBackColor = true;
            this.button_3.Click += new System.EventHandler(this.button_3_Click);
            // 
            // button_6
            // 
            this.button_6.Location = new System.Drawing.Point(206, 264);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(45, 24);
            this.button_6.TabIndex = 5;
            this.button_6.Text = "6";
            this.button_6.UseVisualStyleBackColor = true;
            this.button_6.Click += new System.EventHandler(this.button_6_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(283, 344);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(45, 24);
            this.button6.TabIndex = 6;
            this.button6.Text = "=";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(283, 264);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(45, 24);
            this.button7.TabIndex = 7;
            this.button7.Text = "-";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(283, 224);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(45, 24);
            this.button8.TabIndex = 8;
            this.button8.Text = "+";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(206, 186);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(45, 24);
            this.button9.TabIndex = 9;
            this.button9.Text = "%";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(137, 185);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(45, 24);
            this.button10.TabIndex = 10;
            this.button10.Text = "+/-";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Output
            // 
            this.Output.Location = new System.Drawing.Point(69, 115);
            this.Output.Name = "Output";
            this.Output.ReadOnly = true;
            this.Output.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Output.Size = new System.Drawing.Size(377, 54);
            this.Output.TabIndex = 0;
            this.Output.Text = "\n-------------------------";
            this.Output.TextChanged += new System.EventHandler(this.Output_TextChanged);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 464);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button_6);
            this.Controls.Add(this.button_3);
            this.Controls.Add(this.button_2);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button_9);
            this.Controls.Add(this.button_8);
            this.Controls.Add(this.button_7);
            this.Controls.Add(this.button_5);
            this.Controls.Add(this.button_4);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button1);
            this.Name = "Calculator";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button button1;
        private Button button_1;
        private Button button_4;
        private Button button_7;
        private Button button5;
        private Button button_8;
        private Button button_5;
        private Button button_9;
        private Button button13;
        private Button button14;
        private Button button19;
        private Button button_2;
        private Button button_3;
        private Button button_6;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private RichTextBox Output;
    }
}