
namespace CalcualtorGUI
{


    public partial class Calculator : Form
    {
        Solver calculator = new Solver();

        public Calculator()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '1';
            calculator.Accumulate("1");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '0';
            calculator.Accumulate("0");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '.';
            calculator.Accumulate(".");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '5';
            calculator.Accumulate("5");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + "/";
            calculator.Accumulate("/");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_4_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '4';
            calculator.Accumulate("4");
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '7';
            calculator.Accumulate("7");
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '8';
            calculator.Accumulate("8");
        }

        private void button_9_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '9';
            calculator.Accumulate("9");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + "x";
            calculator.Accumulate("*");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Output.Text = "";
            calculator.Clear();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '2';
            calculator.Accumulate("2");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '-';
            calculator.Accumulate("-");
        }

        private void button_3_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '3';
            calculator.Accumulate("3");
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Output.Text = Output.Text + "+";
            calculator.Accumulate("+");
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Output.Text = Convert.ToString(calculator.Solve());
            calculator.Clear();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + "%";
            calculator.Accumulate("%");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '-';
            calculator.Accumulate("-");
        }

        private void Output_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_6_Click(object sender, EventArgs e)
        {
            Output.Text = Output.Text + '6';
            calculator.Accumulate("6");
        }
    }

}