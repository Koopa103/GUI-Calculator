﻿
using System;
using System.Collections;
using System.Text.RegularExpressions;




namespace CalcualtorGUI
{


	class Solver : ISolve
	{
        bool Symbolcheck(string v)
        {
            return (v == "+" || v == "-" || v == "*" || v == "/");
        }
        string sequation;
		Stack equation = new Stack();
		public void Accumulate(string s)
		{
			sequation += s;
		}
		public double Solve()
		{
			double total = 0;
			string [] lista = Regex.Split(sequation, @"([*\/\%\+\-])");

            for (int i = 0; i < lista.Length; i++)
			{
				if (i == 0 && Symbolcheck(lista[i]))
				{
					if (lista[i] == "-")
					{
						equation.Push(lista[i] + lista[i + 1]);
						i += 2;
					}
				}
				else if (Symbolcheck(lista[i]))
				{
					if (lista[i] == "*" || lista[i] == "/")
					{
						if (lista[i + 1] == "-")
						{
							equation.Push((lista[i] == "*") ? (Convert.ToDouble(equation.Pop()) * Convert.ToDouble(lista[i + 2])) * -1 : (Convert.ToDouble(equation.Pop()) / Convert.ToDouble(lista[i + 2]) * -1));
							i += 2;
						}
						else
						{
							equation.Push((lista[i] == "*") ? (Convert.ToDouble(equation.Pop()) * Convert.ToDouble(lista[i + 1])) : (Convert.ToDouble(equation.Pop()) / Convert.ToDouble(lista[i + 1])));
							i++;
						}

					}
					else if (lista[i] == "%")
					{
						if (lista[i + 1] == "-")
						{
							equation.Push((Convert.ToDouble(equation.Pop()) % Convert.ToDouble(lista[i + 2]) * -1));
							i += 2;
						}
						else
							equation.Push((Convert.ToDouble(equation.Pop()) % Convert.ToDouble(lista[i + 1])));
					}
				}
				else
					if(i != 0)
						if (lista[i - 1] == "-") equation.Push(Convert.ToDouble(lista[i]) * -1);
						else equation.Push(Convert.ToDouble(lista[i]));
					else
						equation.Push(Convert.ToDouble(lista[i]));
            }
			while(equation.Count != 0)
			{
				total += Convert.ToDouble(equation.Pop());
			}
			return total;
		}

		public void Clear()
		{
			equation = new Stack();
			sequation = "";
		}

	}
}
